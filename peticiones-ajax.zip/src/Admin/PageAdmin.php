<?php

namespace PJAX\Admin;

class PageAdmin extends Admin
{
    function index()
    {

    }

}
