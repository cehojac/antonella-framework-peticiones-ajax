<?php
namespace PJAX;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
