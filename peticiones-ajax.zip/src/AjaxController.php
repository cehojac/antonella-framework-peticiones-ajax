<?php
    namespace PJAX;
          
    class AjaxController
    {
    
        public function __construct()
        {
    
        }

        public function MostrarBoton()
        {
            $html = <<<EOT

<form method="POST">
<h1>Probamos nuestro AJAX</h1>
<div class="form-group">
<label for="valor1">Valor para enviar por AJAX</label>
<input type="text" class="form-control" id="valor1" name="valor1" value="">
<small id="emailHelp" class="form-text text-muted">Puedes poner aqui tu valor para enviar por ajax</small>
</div>
<button type="submit" name="enviar_ajax" class="btn btn-primary">Enviar</button>
</form>
<script type="text/javascript">
jQuery(document).ready({
    var data = {
      'action': 'mi_peticion_ajax',
      'post_type': 'POST',
      'name': 'Mi primer ajax'
    };
  
    jQuery.post(ajaxurl, data, function(response) {
      alert( response );
    }, 'json');
  });
</script>

EOT;

return $html;
        }

        public function procesar_ajax()
        {
            $post	= isset($_POST)?$_POST:"";
            $response	= array();
            $response['message']	= "Successfull Request";
            $response['values']     = $post;
            wp_send_json($response);
            exit;
        }
    }